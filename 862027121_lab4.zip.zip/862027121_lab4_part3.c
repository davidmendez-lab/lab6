//inputs = pin outputs = port

    /* Insert your solution below */
 /*	Author: David MEndez
 *  Partner(s) Name: 
 *	Lab Section: 022
 *	Assignment: Lab 4  Exercise 3
 *	Exercise Description: [optional - include for your own benefit]
 *
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#ifdef _SIMULATE_
#include "simAVRHeader.h"
#endif


//inputs = pin outputs = port

    /* Insert your solution below */

	enum Door_States {LOCKED, L1, L2, UNLOCKED} Door_state;

void Tick_Door() {
	//transitions
	switch (Door_state) {
		case LOCKED:
			if (PINA == 0x04)
			{
				Door_state = L1;
			}
			else 
			{
				Door_state = LOCKED;
			}
			break;
		case L1:
			if (PINA == 0x00) 
			{
				Door_state = L2;
			}
			else if(PINA == 0x04) 
			{
				Door_state = L1;
			}
			else 
			{
				Door_state = LOCKED;
			}
			break;

		case L2:
			if (PINA == 0x02)
			{
				Door_state = UNLOCKED;
			}
			else 
			{
				Door_state = L2;
			}
			break;

		case UNLOCKED:
			if (PINA >= 0x80)
			 {
				Door_state = LOCKED;
			}
			break;
		
		default:	
			Door_state = LOCKED;	
	}

	//state actions
	switch (Door_state) 
	{
		case LOCKED:
			PORTB = 0x00;
			break;
		case L1:
			PORTB = 0x00;
			break;
		case L2:
			PORTB = 0x00;
			break;
		case UNLOCKED:
			PORTB = 0x01;
			break;

		default:
			PORTB = 0x00;
			break;

	}	
}

int main(void) {
    // /* Insert DDR and PORT initializations */
		// 0x00 == input, 0xFF == output
		DDRA = 0x00; PORTA = 0xFF;
		DDRB = 0xFF; PORTB = 0x00;
		DDRC = 0xFF; PORTC = 0x00;
    // /* Insert your solution below */    	
		// //initialize state and output
		Door_state = LOCKED;

    	while (1) {
			Tick_Door();
    	}
    return 1;
}