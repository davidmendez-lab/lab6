/*	Author: David MEndez
 *  Partner(s) Name: 
 *	Lab Section: 022
 *	Assignment: Lab 4  Exercise 1
 *	Exercise Description: [optional - include for your own benefit]
 *
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#ifdef _SIMULATE_
#include "simAVRHeader.h"
#endif


//inputs = pin outputs = port

    /* Insert your solution below */
    //unsigned char tmpA = 0x00;
    //unsigned char tmpB = 0x00;

	enum LED_States {LED_SMStart, LED_Init, LED_Firststate, LED_Secondstate, LED_Thirdstate, LED_Fourthstate} LED_State;
	
	void TickFct_LED(void)
	{//statrt of tick function
		switch(LED_State) // transitions
		{ // start of transitions
			case LED_SMStart:
				LED_State = LED_Init;
				break;
			
			case LED_Init:
				LED_State = LED_Firststate;
				break;
		
			case LED_Firststate:
				if (PINA == 0x00)
				{				//start of first if statement
					LED_State = LED_Firststate;
				} 				//end of first if statement
				else if(PINA == 0x01)
				{				//start of second if statement 
					LED_State = LED_Secondstate;
				}				//end of secodn if statement
				break;

			case LED_Secondstate:
				if(PINA == 0x01)
				{				//start of 3rd if statement
					LED_State = LED_Secondstate;
				}				//end of 3rd of statement
				else if(PINA ==0x00)
				{				//start of 4th if statement
					LED_State = LED_Thirdstate;
				}				//end of 4th if statement
				break;
			
			case LED_Thirdstate:
				if(PINA == 0x00)
				{				//start of 5 if statement
					LED_State = LED_Thirdstate;
				}				//end of 5 of statement
				else if(PINA == 0x01)
				{				//start of 6th if statement
					LED_State = LED_Fourthstate;
				}				//end of 6th if statement
				break;
			
			case LED_Fourthstate:
				if(PINA == 0x01)
				{				//start of 7 if statement
					LED_State = LED_Fourthstate;
				}				//end of 7 if statement
				else if(PINA == 0x01)
				{				//start of 8th if statement
					LED_State = LED_Firststate;
				}				//end of 8th if statement
				break;
			default:
				LED_State  = LED_SMStart;
				break;
		} //end of transitions

		switch(LED_State)
		{ // statrt of state actions
			case LED_SMStart:
				PORTB = 0x00;
				break;
			
			case LED_Init:
				PORTB = 0x00;
				break;
			
			case LED_Firststate: 
				PORTB = 0x01;
				break;

			case LED_Secondstate:
				PORTB = 0x02;
				break;

			case LED_Thirdstate:
				PORTB = 0x02;
				break;
			
			case LED_Fourthstate:
				PORTB = 0x01;
				break;
						
			default:
				break;
		} // end of state actions
	}// end of tick function
int main() 
{
    /* Insert DDR and PORT initializations */
	DDRA = 0x00; PORTA = 0xFF; //inputs
	DDRB = 0xFF; PORTB = 0x00; //outputs
   	
		PORTB = 0x00;	
		LED_State = LED_SMStart;
    		
		while (1) 
		{            
			TickFct_LED();
		}
return 1;
}

